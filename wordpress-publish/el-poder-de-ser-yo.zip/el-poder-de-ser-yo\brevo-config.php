<?php
// Server-only. Do not expose this file publicly if the host serves .php source.
return [
  'api_key' => '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',
];
