<?php
/**
 * Plugin Name: Todos a Bordo — Regalo para tu peque
 * Description: Página Elementor editable con el formulario de descarga conectado a Brevo (listas + bienvenida).
 * Version: 1.0.0
 * Author: Todos a Bordo CR
 * Text Domain: todos-regalo-form
 */

if (!defined('ABSPATH')) {
  exit;
}

define('TAB_REGALO_VERSION', '1.0.0');
define('TAB_REGALO_PATH', plugin_dir_path(__FILE__));
define('TAB_REGALO_URL', plugin_dir_url(__FILE__));
define('TAB_REGALO_PAGE_SLUG', 'un-regalo-para-tu-peque');

register_activation_hook(__FILE__, 'tab_regalo_activate');
add_action('init', 'tab_regalo_register_shortcode');
add_action('wp_enqueue_scripts', 'tab_regalo_enqueue_assets');

/**
 * On activate: create (or refresh) the public form page.
 */
function tab_regalo_activate() {
  $existing = get_page_by_path(TAB_REGALO_PAGE_SLUG);
  $page_id = $existing ? (int) $existing->ID : 0;

  if (!$page_id) {
    $page_id = wp_insert_post([
      'post_title'   => 'Un regalo para tu peque!',
      'post_name'    => TAB_REGALO_PAGE_SLUG,
      'post_status'  => 'publish',
      'post_type'    => 'page',
      'post_content' => '[todos_regalo_form]',
    ]);
  } else {
    wp_update_post([
      'ID'           => $page_id,
      'post_status'  => 'publish',
      'post_content' => '[todos_regalo_form]',
    ]);
  }

  if (is_wp_error($page_id) || !$page_id) {
    return;
  }

  update_option('tab_regalo_page_id', $page_id);

  // Prefer Elementor canvas so the branded form is the full composition.
  update_post_meta($page_id, '_wp_page_template', 'elementor_canvas');

  if (did_action('elementor/loaded') || class_exists('\\Elementor\\Plugin')) {
    tab_regalo_seed_elementor_page($page_id);
  }

  flush_rewrite_rules();
}

/**
 * Seed a simple Elementor structure: one HTML widget with the branded form.
 * Gustavo can open Elementor and edit texts/images without a developer.
 */
function tab_regalo_seed_elementor_page($page_id) {
  $html = tab_regalo_form_markup(true);

  $elementor_data = [
    [
      'id' => 'tabreg001',
      'elType' => 'section',
      'settings' => [
        'layout' => 'full_width',
        'gap' => 'no',
        'padding' => [
          'unit' => 'px',
          'top' => '0',
          'right' => '0',
          'bottom' => '0',
          'left' => '0',
          'isLinked' => true,
        ],
      ],
      'elements' => [
        [
          'id' => 'tabreg002',
          'elType' => 'column',
          'settings' => [
            '_column_size' => 100,
          ],
          'elements' => [
            [
              'id' => 'tabreg003',
              'elType' => 'widget',
              'widgetType' => 'html',
              'settings' => [
                'html' => $html,
              ],
              'elements' => [],
            ],
          ],
        ],
      ],
    ],
  ];

  update_post_meta($page_id, '_elementor_edit_mode', 'builder');
  update_post_meta($page_id, '_elementor_template_type', 'wp-page');
  update_post_meta($page_id, '_elementor_version', '3.20.0');
  update_post_meta($page_id, '_elementor_data', wp_slash(wp_json_encode($elementor_data)));
  delete_post_meta($page_id, '_elementor_css');
}

function tab_regalo_register_shortcode() {
  add_shortcode('todos_regalo_form', 'tab_regalo_shortcode');
}

function tab_regalo_shortcode() {
  tab_regalo_enqueue_assets(true);
  return tab_regalo_form_markup(false);
}

function tab_regalo_enqueue_assets($force = false) {
  if (!$force && !is_singular() && !is_page(TAB_REGALO_PAGE_SLUG)) {
    // Still allow shortcode pages / Elementor canvas
  }
  wp_enqueue_style(
    'tab-regalo-fonts',
    'https://fonts.googleapis.com/css2?family=Nunito:wght@700;800&family=Work+Sans:wght@400;500;600;700&display=swap',
    [],
    null
  );
  wp_enqueue_style(
    'tab-regalo-form',
    TAB_REGALO_URL . 'assets/form.css',
    ['tab-regalo-fonts'],
    TAB_REGALO_VERSION
  );
  wp_enqueue_script(
    'tab-regalo-form',
    TAB_REGALO_URL . 'assets/form.js',
    [],
    TAB_REGALO_VERSION,
    true
  );
}

function tab_regalo_banner_url() {
  return TAB_REGALO_URL . 'assets/portada-formulario.png';
}

function tab_regalo_brevo_action() {
  return 'https://d65b6039.sibforms.com/serve/MUIFANLrjM8SUZRdGeAtRgMIaNKiWTcVoqZIhk8xaPAaEKMcV6s-wUFhOpk-vvAC9e9WBF-H3NmCUAzR9ayL_sG0CJsnHVJ8Kvbyz_bJppD6szJaEMbOG1AKWNAztCtWGm7A8va7RfPYJFPdn9gm5HLKprVOLVPZETqAzps3ow-hJL356bQDHlUJiZeP1EKSxMsLzCDrJJ9G10L3Pg==';
}

function tab_regalo_thanks_url() {
  $custom = get_option('tab_regalo_thanks_url');
  if (is_string($custom) && $custom !== '') {
    return $custom;
  }
  return 'https://miyamotogenji.github.io/regalo-para-tu-peque/gracias.html';
}

/**
 * @param bool $inline_assets When seeding Elementor HTML widget, inline CSS/JS so it works alone.
 */
function tab_regalo_form_markup($inline_assets = false) {
  $banner = esc_url(tab_regalo_banner_url());
  $action = esc_url(tab_regalo_brevo_action());
  $thanks = esc_url(tab_regalo_thanks_url());
  $css_url = esc_url(TAB_REGALO_URL . 'assets/form.css?v=' . TAB_REGALO_VERSION);
  $js_url = esc_url(TAB_REGALO_URL . 'assets/form.js?v=' . TAB_REGALO_VERSION);

  ob_start();
  if ($inline_assets) {
    echo '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@700;800&family=Work+Sans:wght@400;500;600;700&display=swap" />';
    echo '<link rel="stylesheet" href="' . $css_url . '" />';
  }
  ?>
  <div class="tab-regalo" data-thanks="<?php echo esc_attr($thanks); ?>">
    <div class="tab-regalo__shell">
      <img class="tab-regalo__banner" src="<?php echo $banner; ?>" alt="Qué bueno que querás seguir aprendiendo nuevas formas de acompañar a tu peque. Este regalo es un recurso más para hacerlo." />
      <div class="tab-regalo__card">
        <div id="error-message" class="tab-regalo__msg tab-regalo__msg--error" hidden>
          No pudimos guardar tu suscripción. Por favor intentá de nuevo.
        </div>
        <div id="success-message" class="tab-regalo__msg tab-regalo__msg--ok" hidden>
          ¡Listo! Ya estás a bordo. Te llevamos a tu descarga…
        </div>

        <iframe name="sib_frame" id="sib_frame" title="Brevo" style="display:none"></iframe>
        <form id="sib-form" class="tab-regalo__form" method="POST" target="sib_frame" action="<?php echo $action; ?>">
          <h1 class="tab-regalo__title">Un regalo para tu peque!</h1>
          <p class="tab-regalo__lead">
            Completá tus datos para unirte a nuestra comunidad digital y descargar gratis la
            <strong>Guía práctica para fortalecer las funciones ejecutivas</strong>.
          </p>

          <label for="NOMBRE_COMPLETO">Nombre completo *</label>
          <input id="NOMBRE_COMPLETO" name="NOMBRE_COMPLETO" type="text" autocomplete="name" placeholder="Tu nombre completo" required />

          <label for="EMAIL">Correo electrónico *</label>
          <input id="EMAIL" name="EMAIL" type="email" autocomplete="email" placeholder="tu@correo.com" required />

          <label class="tab-regalo__check">
            <input type="checkbox" id="OPT_IN" name="OPT_IN" value="1" required />
            <span>Quiero unirme a la comunidad digital de Todos a Bordo y recibir información sobre recursos, actividades y talleres. *</span>
          </label>
          <p class="tab-regalo__hint">Podés cancelar tu suscripción en cualquier momento usando el enlace en nuestros correos.</p>

          <input type="text" name="email_address_check" value="" tabindex="-1" autocomplete="off" style="display:none" />
          <input type="hidden" name="locale" value="es" />

          <button type="submit">💛 DESCARGAR MI GUÍA GRATIS</button>
        </form>
      </div>
    </div>
    <p class="tab-regalo__foot">todos a bordo · Gustavo Mora</p>
  </div>
  <?php
  if ($inline_assets) {
    echo '<script src="' . $js_url . '"></script>';
  }
  return ob_get_clean();
}
