(function () {
  function boot(root) {
    var form = root.querySelector("#sib-form") || document.getElementById("sib-form");
    var frame = root.querySelector("#sib_frame") || document.getElementById("sib_frame");
    var err = root.querySelector("#error-message") || document.getElementById("error-message");
    var ok = root.querySelector("#success-message") || document.getElementById("success-message");
    if (!form || !frame) return;

    var btn = form.querySelector('button[type="submit"]');
    var pending = false;
    var thanks =
      (root.getAttribute && root.getAttribute("data-thanks")) ||
      "https://miyamotogenji.github.io/regalo-para-tu-peque/gracias.html";

    function show(el, visible) {
      if (!el) return;
      if (visible) el.removeAttribute("hidden");
      else el.setAttribute("hidden", "hidden");
      el.style.display = visible ? "block" : "none";
    }

    form.addEventListener("submit", function () {
      if (!form.checkValidity()) return;
      pending = true;
      if (btn) btn.disabled = true;
      show(err, false);
      show(ok, false);
    });

    frame.addEventListener("load", function () {
      if (!pending) return;
      pending = false;
      if (btn) btn.disabled = false;
      show(ok, true);
      form.reset();
      window.setTimeout(function () {
        window.location.href = thanks;
      }, 900);
    });
  }

  function init() {
    var roots = document.querySelectorAll(".tab-regalo");
    if (roots.length) {
      roots.forEach(boot);
    } else {
      boot(document);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
